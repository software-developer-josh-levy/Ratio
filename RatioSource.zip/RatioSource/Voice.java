/*
 * Ratio is a just intonation VST synthesizer built in Java. The Java-to-C++ wrapper
 * (jVSTwRapper) which encloses this synth was written by Daniel Martin
 * [daniel309@users.sourceforge.net] and many others. Ratio is adapted from and 
 * inspired by JayVSTxSynth (also written by Daniel Martin) and JSyn (by Phil Burk).
 *
 * Copyright (C) 2016 Josh Levy, https://github.com/software-developer-josh-levy/Ratio
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

package jvst.examples.ratio;

public class Voice {
	private static final float VEL_MULT = 1.0F / 127.0F;

	// ampitude/filter envelope states
	private static final int
		FREE = 0,
		ATTACK = 1,
		DECAY = 2,
		SUSTAIN = 3,
		RELEASE = 4;
		
	private int ampEnvelope = FREE;
	private int filterEnvelope = FREE;
	private int note;
	private int velocity;
	private int onDelta;
	private int offDelta;
	private float volume;
	private float releaseVolume;
	private float subharmLevel;
	private float superharmLevel;
	private float oscMix;
	private float oscDetune;
	private float noiseLevel;
	private float pulseWidth;
	private float filterAmount;
	private float releaseFilterAmount;
	private float filterCutoff;
	private float filterResonance;
	private float LFO1Amount;
	private float LFO2Amount;
	private float LFO1Rate;
	private float LFO2Rate;

	private float ampAttackMS;
	private float ampDecayMS;
	private float ampSustain;
	private float ampReleaseMS;
	private int ampAttackCounter;
	private int ampDecayCounter;
	private int ampReleaseCounter;
	private float filterAttackMS;
	private float filterDecayMS;
	private float filterSustain;
	private float filterReleaseMS;
	private int filterAttackCounter;
	private int filterDecayCounter;
	private int filterReleaseCounter;

	private double currentPhaseOsc1;
	private double currentPhaseOsc2;
	private double currentPhaseOsc3;
	private double currentPhaseOsc4;
	private double currentPhaseOsc5;
	private double currentPhaseOsc6;
	private double currentPhaseLFO1;
	private double currentPhaseLFO2;
	private double previousOffsetLFO1V, currentOffsetLFO1V, intOffsetLFO1V;
	private double previousOffsetLFO1F, currentOffsetLFO1F, intOffsetLFO1F;
	private double previousOffsetLFO1C, currentOffsetLFO1C, intOffsetLFO1C;
	private double previousOffsetLFO1P, currentOffsetLFO1P, intOffsetLFO1P;
	private double previousOffsetLFO2V, currentOffsetLFO2V, intOffsetLFO2V;
	private double previousOffsetLFO2F, currentOffsetLFO2F, intOffsetLFO2F;
	private double previousOffsetLFO2C, currentOffsetLFO2C, intOffsetLFO2C;
	private double previousOffsetLFO2P, currentOffsetLFO2P, intOffsetLFO2P;
	
	private double detuneModUp, detuneModDown;
	private double LFO1Mod, LFO2Mod;
	private double valNoise;
	private double valLFO1, valLFO2;
	private double valOsc1, valOsc2, valOsc3, valOsc4, valOsc5, valOsc6;
	
	private Ratio instance = Ratio.getInstance();
	private Scales scales = instance.getScales();
	private Oscillator osc = instance.getOsc();
	private	PinkNoise pinkNoise = instance.getPinkNoise();
	private Filter filter;
	private double filteredSample;
	private HighPass highPassOsc1a;
	private HighPass highPassOsc1b;
	private HighPass highPassOsc2a;
	private HighPass highPassOsc2b;
	
	public Voice() {
		filter = new Filter();
		highPassOsc1a = new HighPass();
		highPassOsc1b = new HighPass();
		highPassOsc2a = new HighPass();
		highPassOsc2b = new HighPass();
	}
		
	public void noteOn(int note, int velocity, int delta, float volume, 
	float ampAttackMS, float ampDecayMS, float ampSustain, float ampReleaseMS, 
	float filterAttackMS, float filterDecayMS, float filterSustain, float filterReleaseMS) {
		onDelta = delta;
		ampEnvelope = ATTACK;
		filterEnvelope = ATTACK;
		this.note = note;
		this.velocity = velocity;
		this.volume = volume;
		this.ampAttackMS = ampAttackMS;
		this.ampDecayMS = ampDecayMS;
		this.ampSustain = ampSustain;
		this.ampReleaseMS = ampReleaseMS;
		this.filterAttackMS = filterAttackMS;
		this.filterDecayMS = filterDecayMS;
		this.filterSustain = filterSustain;
		this.filterReleaseMS = filterReleaseMS;
		subharmLevel = instance.getSubharmLevel();
		superharmLevel = instance.getSuperharmLevel();
		oscMix = instance.getOscMix();
		oscDetune = instance.getOscDetune();
		noiseLevel = instance.getNoiseLevel();
		pulseWidth = instance.getPulseWidth();
		filterAmount = instance.getFilterAmount();
		filterCutoff = instance.getFilterCutoff();
		filterResonance = instance.getFilterResonance();
		LFO1Rate = instance.getLFO1Rate();
		LFO2Rate = instance.getLFO2Rate();
		LFO1Amount = instance.getLFO1Amount();
		LFO2Amount = instance.getLFO2Amount();
		filter.zeroOut();
		highPassOsc1a.zeroOut();
		highPassOsc1b.zeroOut();
		highPassOsc2a.zeroOut();
		highPassOsc2b.zeroOut();
		currentPhaseOsc1 = 0.0;	
		currentPhaseOsc2 = 0.0;
		currentPhaseOsc3 = 0.0;	
		currentPhaseOsc4 = 0.0;
		currentPhaseOsc5 = 0.0;	
		currentPhaseOsc6 = 0.0;
	}
	
	public void noteOff(int delta) {
		offDelta = delta;
		ampEnvelope = RELEASE;
		filterEnvelope = RELEASE;
	}
	
	public void calculateSample(float[][] outputs, float sampleRate, int sampleFrames, double tempo, int j) {
		float[] outputL = outputs[0];
		float[] outputR = outputs[1];
		
		// set amplitude envelope counters to zero at start of note
		if (j != 0 && j == onDelta) {
			ampAttackCounter = 0;
			ampDecayCounter = 0;
			ampReleaseCounter = 0;
			filterAttackCounter = 0;
			filterDecayCounter = 0;
			filterReleaseCounter = 0;
		}
		
		if (ampEnvelope == FREE || j < onDelta) {
			outputL[j] += 0.0;
			outputR[j] += 0.0;
		} else { // calculate voice sample
			// get parameters and interpolate changes
			float previousVolume = volume;
			float currentVolume = instance.getVolume();
			volume += (currentVolume - previousVolume) / 1024;
			float volumeBase = volume; // establish pre-envelope/modulation level
			
			float previousSubharmLevel = subharmLevel;
			float currentSubharmLevel = instance.getSubharmLevel();
			if (currentSubharmLevel == 0) {
				subharmLevel = 0;
			} else {
				subharmLevel += (currentSubharmLevel - previousSubharmLevel) / 1024;
			}
			
			float previousSuperharmLevel = superharmLevel;
			float currentSuperharmLevel = instance.getSuperharmLevel();
			if (currentSuperharmLevel == 0) {
				superharmLevel = 0;
			} else {
				superharmLevel += (currentSuperharmLevel - previousSuperharmLevel) / 1024;
			}
		
			float previousOscMix = oscMix;
			float currentOscMix = instance.getOscMix();
			oscMix += (currentOscMix - previousOscMix) / 1024;			
			
			float previousOscDetune = oscDetune;
			float currentOscDetune = instance.getOscDetune();
			if (currentOscDetune == 0) {
				oscDetune = 0;
			} else {
				oscDetune += (currentOscDetune - previousOscDetune) / 1024;
			}
			
			float previousNoiseLevel = noiseLevel;
			float currentNoiseLevel = instance.getNoiseLevel();
			if (currentNoiseLevel == 0) {
				noiseLevel = 0;
			} else {
				noiseLevel += (currentNoiseLevel - previousNoiseLevel) / 1024;
			}
			
			float previousPulseWidth = pulseWidth;
			float currentPulseWidth = instance.getPulseWidth();
			pulseWidth += (currentPulseWidth - previousPulseWidth) / 1024;
			float pulseWidthBase = pulseWidth; // establish pre-modulation level
			
			float previousFilterAmount = filterAmount;
			float currentFilterAmount = instance.getFilterAmount();
			if (currentFilterAmount == 0 || filterEnvelope == FREE) {
				filterAmount = 0;
			} else {
				filterAmount += (currentFilterAmount - previousFilterAmount) / 1024;
			}
			float filterAmountBase = filterAmount; // establish pre-envelope/modulation level
	
			float previousFilterCutoff = filterCutoff;
			float currentFilterCutoff = instance.getFilterCutoff();
			filterCutoff += (currentFilterCutoff - previousFilterCutoff) / 1024;
			float filterCutoffBase = filterCutoff; // establish pre-modulation level

			float previousFilterResonance = filterResonance;
			float currentFilterResonance = instance.getFilterResonance();
			filterResonance += (currentFilterResonance - previousFilterResonance) / 1024;
			
			float previousLFO1Amount = LFO1Amount;
			float currentLFO1Amount = instance.getLFO1Amount();
			if (currentLFO1Amount == 0) {
				LFO1Amount = 0;
			} else {
				LFO1Amount += (currentLFO1Amount - previousLFO1Amount) / 1024;
			}
			
			float previousLFO2Amount = LFO2Amount;
			float currentLFO2Amount = instance.getLFO2Amount();
			if (currentLFO2Amount == 0) {
				LFO2Amount = 0;
			} else {
				LFO2Amount += (currentLFO2Amount - previousLFO2Amount) / 1024;
			}
			
			float previousLFO1Rate = LFO1Rate;
			float currentLFO1Rate = instance.getLFO1Rate();
			LFO1Rate += (currentLFO1Rate - previousLFO1Rate) / 1024;
			/*
			if (currentLFO1Rate == 0) {
				LFO1Rate = 0;
			} else {
				LFO1Rate += (currentLFO1Rate - previousLFO1Rate) / 1024;
			}
			*/
			
			float previousLFO2Rate = LFO2Rate;
			float currentLFO2Rate = instance.getLFO2Rate();
			LFO2Rate += (currentLFO2Rate - previousLFO2Rate) / 1024;
			
			float osc1Shape = instance.getOsc1Shape();
			float osc2Shape = instance.getOsc2Shape();
			float osc1Octave = instance.getOsc1Octave();
			float osc2Octave = instance.getOsc2Octave();
			float subharmFreq = instance.getSubharmFreq();
			float superharmFreq = instance.getSuperharmFreq();
			float filterType = instance.getFilterType();
			float LFO1Shape = instance.getLFO1Shape();
			float LFO2Shape = instance.getLFO2Shape();
			float LFO1Destination = instance.getLFO1Destination();
			float LFO2Destination = instance.getLFO2Destination();		

			// convert MIDI note to Hz value and transpose
			float frequency = calculateFrequency(note);
			float frequencyOsc1 = transposeByOcts(osc1Octave, frequency);
			float frequencyOsc2 = transposeByOcts(osc2Octave, frequency);
			float frequencyOsc3 = transposeBySub(subharmFreq, frequencyOsc1);
			float frequencyOsc4 = transposeBySub(subharmFreq, frequencyOsc2);
			float frequencyOsc5 = transposeBySuper(superharmFreq, frequencyOsc1);
			float frequencyOsc6 = transposeBySuper(superharmFreq, frequencyOsc2);			
			
			// convert frequencies to phase increments
			double phaseIncrementOsc1 = frequencyOsc1 * (2 / sampleRate);
			double phaseIncrementOsc2 = frequencyOsc2 * (2 / sampleRate);
			double phaseIncrementOsc3 = frequencyOsc3 * (2 / sampleRate);
			double phaseIncrementOsc4 = frequencyOsc4 * (2 / sampleRate);
			double phaseIncrementOsc5 = frequencyOsc5 * (2 / sampleRate);
			double phaseIncrementOsc6 = frequencyOsc6 * (2 / sampleRate);	
			
			// apply filter envelope
			if (filterEnvelope == ATTACK) {
				int filterAttackSamples = (int)(sampleRate / 1000 * filterAttackMS);
				if (filterAttackCounter <= filterAttackSamples) {
					filterAmount = filterAmount/filterAttackSamples * filterAttackCounter;
					releaseFilterAmount = filterAmount;
					filterAttackCounter++;
				} else {
					filterEnvelope = DECAY;
				}
			}
			
			if (filterEnvelope == DECAY) {
				if (filterDecayMS < 10) {
					filterDecayMS = 10;
				}
				int filterDecaySamples = (int)(sampleRate / 1000 * filterDecayMS);
				if (filterDecayCounter <= filterDecaySamples) {
					filterAmount -= filterAmount/filterDecaySamples * filterDecayCounter * (1 - filterSustain);
					releaseFilterAmount = filterAmount;
					filterDecayCounter++;
				} else {
					filterEnvelope = SUSTAIN;
				}
			}
			
			if (filterEnvelope == SUSTAIN) {
				filterAmount *= filterSustain;
				releaseFilterAmount = filterAmount;
			}
			
			if (filterEnvelope == RELEASE) {
				if (filterReleaseMS < 1) {
					filterReleaseMS = 1;
				}
				if (filterReleaseMS == 16000) {
					filterAmount = releaseFilterAmount;
				} else {
					int filterReleaseSamples = (int)(sampleRate / 1000 * filterReleaseMS);
					if (filterReleaseCounter <= filterReleaseSamples) {
						filterAmount = releaseFilterAmount;
						filterAmount -= releaseFilterAmount/filterReleaseSamples * filterReleaseCounter;
						if (j >= offDelta) {
							filterReleaseCounter++;
						}
					} else {
						filterEnvelope = FREE;
						filterAmount = 0;
					}
				}
			}	
			
			// apply amplitude envelope
			if (ampEnvelope == ATTACK) {
				if (ampAttackMS < 1) {
					ampAttackMS = 1;
				}
				int ampAttackSamples = (int)(sampleRate / 1000 * ampAttackMS);
				if (ampAttackCounter <= ampAttackSamples) {
					volume = volume/ampAttackSamples * ampAttackCounter;
					releaseVolume = volume;
					ampAttackCounter++;
				} else {
					ampEnvelope = DECAY;
				}
			}
			
			if (ampEnvelope == DECAY) {
				if (ampDecayMS < 10) {
					ampDecayMS = 10;
				}
				int ampDecaySamples = (int)(sampleRate / 1000 * ampDecayMS);
				if (ampDecayCounter <= ampDecaySamples) {
					volume -= volume/ampDecaySamples * ampDecayCounter * (1 - ampSustain);
					releaseVolume = volume;
					ampDecayCounter++;
				} else {
					ampEnvelope = SUSTAIN;
				}
			}
			
			if (ampEnvelope == SUSTAIN) {
				volume *= ampSustain;
				releaseVolume = volume;
			}
			
			if (ampEnvelope == RELEASE) {
				if (ampReleaseMS < 1) {
					ampReleaseMS = 1;
				}			
				int ampReleaseSamples = (int)(sampleRate / 1000 * ampReleaseMS);
				if (ampReleaseCounter <= ampReleaseSamples) {
					volume = releaseVolume;
					volume -= releaseVolume/ampReleaseSamples * ampReleaseCounter;
					if (j >= offDelta) {
						ampReleaseCounter++;
					}
				} else {
					ampEnvelope = FREE;
					filterEnvelope = FREE;
					volume = 0;
				}
			}
			
			// calculate and apply detune
			if (oscDetune > 0) {
				detuneModUp = Math.pow(2, (6 * oscDetune) / 1200);
				detuneModDown = Math.pow(2, -((6 * oscDetune) / 1200));
				phaseIncrementOsc1 *= detuneModUp;
				phaseIncrementOsc2 *= detuneModDown;
				if (subharmLevel > 0) {
					phaseIncrementOsc3 *= detuneModUp;
					phaseIncrementOsc4 *= detuneModDown;
				}
				if (superharmLevel > 0) {
					phaseIncrementOsc5 *= detuneModUp;
					phaseIncrementOsc6 *= detuneModDown;
				}
			}

			// calculate LFO1 sample
			double phaseIncrementLFO1 = (LFO1Rate * 8) * (2 / sampleRate); 
			currentPhaseLFO1 = incrementWrapPhase(currentPhaseLFO1, phaseIncrementLFO1);
			// if (LFO1Amount > 0 && LFO1Rate > 0) {
			if (LFO1Amount > 0) {
				valLFO1 = osc.calculateSample(LFO1Shape, 0.0F, currentPhaseLFO1, phaseIncrementLFO1);
			}
			
			// calculate LFO2 sample
			double phaseIncrementLFO2 = (tempo / (15 * Math.pow(2, (int)(LFO2Rate * 8)))) * (2 / sampleRate);
			currentPhaseLFO2 = incrementWrapPhase(currentPhaseLFO2, phaseIncrementLFO2);		
			if (LFO2Amount > 0) {			
				valLFO2 = osc.calculateSample(LFO2Shape, 0.0F, currentPhaseLFO2, phaseIncrementLFO2);
			}
			
			// apply LFO1--unsynced
			// if (LFO1Amount > 0 && LFO1Rate > 0) {
			if (LFO1Amount > 0) {
				LFO1Mod = LFO1Amount * LFO1Amount * LFO1Amount; 
				if (LFO1Destination < 0.25) { // modulate "volume"
					currentOffsetLFO1V = 0.5 * volume * valLFO1 * LFO1Mod;
					intOffsetLFO1V = interpolateLFO(previousOffsetLFO1V, currentOffsetLFO1V, 128);
					volume += (float)intOffsetLFO1V;
					previousOffsetLFO1V = intOffsetLFO1V;
				} else if (LFO1Destination < 0.5) { // modulate frequency
					currentOffsetLFO1F = Math.pow(2, valLFO1 * LFO1Mod);
					intOffsetLFO1F = interpolateLFO(previousOffsetLFO1F, currentOffsetLFO1F, 256);
					phaseIncrementOsc1 *= intOffsetLFO1F;
					phaseIncrementOsc2 *= intOffsetLFO1F;
					phaseIncrementOsc3 *= intOffsetLFO1F;
					phaseIncrementOsc4 *= intOffsetLFO1F;
					phaseIncrementOsc5 *= intOffsetLFO1F;
					phaseIncrementOsc6 *= intOffsetLFO1F;	
					previousOffsetLFO1F = intOffsetLFO1F;
				} else if (LFO1Destination < 0.75) { // modulate "filterCutoff"
					currentOffsetLFO1C = 0.5 * valLFO1 * LFO1Mod;
					intOffsetLFO1C = interpolateLFO(previousOffsetLFO1C, currentOffsetLFO1C, 256);
					filterCutoff += (float)intOffsetLFO1C;
					previousOffsetLFO1C = intOffsetLFO1C;
					if (filterCutoff < 0.005F) { // minimum cutoff
						filterCutoff = 0.005F;
					}
				} else { // modulate "pulseWidth" for both OSCs
					currentOffsetLFO1P = 0.5 * valLFO1 * LFO1Mod;
					intOffsetLFO1P = interpolateLFO(previousOffsetLFO1P, currentOffsetLFO1P, 512);
					pulseWidth += (float)intOffsetLFO1P;
					previousOffsetLFO1P = intOffsetLFO1P;
				}
			}
			
			// apply LFO2--tempo sync
			if (LFO2Amount > 0) {
				LFO2Mod = LFO2Amount * LFO2Amount * LFO2Amount; 
				if (LFO2Destination < 0.25) { // modulate "volume"
					currentOffsetLFO2V = 0.5 * volume * valLFO2 * LFO2Mod;
					intOffsetLFO2V = interpolateLFO(previousOffsetLFO2V, currentOffsetLFO2V, 128);
					volume += (float)intOffsetLFO2V;
					previousOffsetLFO2V = intOffsetLFO2V;
				} else if (LFO2Destination < 0.5) { // modulate frequency
					currentOffsetLFO2F = Math.pow(2, valLFO2 * LFO2Mod);
					intOffsetLFO2F = interpolateLFO(previousOffsetLFO2F, currentOffsetLFO2F, 256);
					phaseIncrementOsc1 *= intOffsetLFO2F;
					phaseIncrementOsc2 *= intOffsetLFO2F;
					phaseIncrementOsc3 *= intOffsetLFO2F;
					phaseIncrementOsc4 *= intOffsetLFO2F;
					phaseIncrementOsc5 *= intOffsetLFO2F;
					phaseIncrementOsc6 *= intOffsetLFO2F;
					previousOffsetLFO2F = intOffsetLFO2F;
				} else if (LFO2Destination < 0.75) { // modulate "filterCutoff"
					currentOffsetLFO2C = 0.5 * valLFO2 * LFO2Mod;
					intOffsetLFO2C = interpolateLFO(previousOffsetLFO2C, currentOffsetLFO2C, 256);
					filterCutoff += (float)intOffsetLFO2C;
					previousOffsetLFO2C = intOffsetLFO2C;
					if (filterCutoff < 0.005F) { // minimum cutoff
						filterCutoff = 0.005F;
					}
				} else { // modulate "pulseWidth" for both OSCs
					currentOffsetLFO2P = 0.5 * valLFO2 * LFO2Mod;
					intOffsetLFO2P = interpolateLFO(previousOffsetLFO2P, currentOffsetLFO2P, 512);
					pulseWidth += (float)intOffsetLFO2P;
					previousOffsetLFO2P = intOffsetLFO2P;
				}
			}

			// increment oscillator phases
			currentPhaseOsc1 = incrementWrapPhase(currentPhaseOsc1, phaseIncrementOsc1);
			currentPhaseOsc2 = incrementWrapPhase(currentPhaseOsc2, phaseIncrementOsc2);
			currentPhaseOsc3 = incrementWrapPhase(currentPhaseOsc3, phaseIncrementOsc3);
			currentPhaseOsc4 = incrementWrapPhase(currentPhaseOsc4, phaseIncrementOsc4);
			currentPhaseOsc5 = incrementWrapPhase(currentPhaseOsc5, phaseIncrementOsc5);
			currentPhaseOsc6 = incrementWrapPhase(currentPhaseOsc6, phaseIncrementOsc6);

			// calculate oscillator samples
			valOsc1 = osc.calculateSample(osc1Shape, pulseWidth, currentPhaseOsc1, phaseIncrementOsc1);
			valOsc2 = osc.calculateSample(osc2Shape, pulseWidth, currentPhaseOsc2, phaseIncrementOsc2);
			if (subharmLevel > 0) {
				valOsc3 = osc.calculateSample(osc1Shape, pulseWidth, currentPhaseOsc3, phaseIncrementOsc3);
				valOsc4 = osc.calculateSample(osc2Shape, pulseWidth, currentPhaseOsc4, phaseIncrementOsc4);
			}
			if (superharmLevel > 0) {
				valOsc5 = osc.calculateSample(osc1Shape, pulseWidth, currentPhaseOsc5, phaseIncrementOsc5);
				valOsc6 = osc.calculateSample(osc2Shape, pulseWidth, currentPhaseOsc6, phaseIncrementOsc6);
			}

			// sum oscillators
			valOsc1 += subharmLevel * subharmLevel * valOsc3 + superharmLevel * subharmLevel * valOsc5;
			valOsc2 += subharmLevel * subharmLevel * valOsc4 + superharmLevel * subharmLevel * valOsc6;
			
			// remove subs from and add make-up gain to pulse waves
			if (osc1Shape >= 0.5 && osc1Shape < 0.75) {
				valOsc1 = highPassOsc1a.applyFilter(valOsc1);
				valOsc1 = highPassOsc1b.applyFilter(valOsc1);
				if (pulseWidth > 0.375) {
					valOsc1 *= 1 + 0.5 * (pulseWidth - 0.375) * (pulseWidth - 0.375) * (pulseWidth - 0.375);
				} else {
					valOsc1 *= 1 + 1.5 * (0.375 - pulseWidth) * (0.375 - pulseWidth) * (0.375 - pulseWidth);
				}
			}
			if (osc2Shape >= 0.5 && osc2Shape < 0.75) {
				valOsc2 = highPassOsc2a.applyFilter(valOsc2);
				valOsc2 = highPassOsc2b.applyFilter(valOsc2);
				if (pulseWidth > 0.375) {
					valOsc2 *= 1 + 0.5 * (pulseWidth - 0.375) * (pulseWidth - 0.375) * (pulseWidth - 0.375);
				} else {
					valOsc2 *= 1 + 1.5 * (0.375 - pulseWidth) * (0.375 - pulseWidth) * (0.375 - pulseWidth);
				}
			}
			
			// add make-up gain to saw waves
			if (osc1Shape >= 0.75) {
				valOsc1 *= 1.375;
			}
			if (osc2Shape >= 0.75) {
				valOsc2 *= 1.375;
			}
			
			// scale "volume" for velocity
			double velVolume = 0.5 * volume * volume * velocity * VEL_MULT;
			valOsc1 *= velVolume;
			valOsc2 *= velVolume;
			
			// calculate noise
			if (noiseLevel > 0) {
				valNoise = 0.125 * pinkNoise.generatePinkNoise() * noiseLevel;
			}
			
			// apply resonant filter
			double unfilteredSample = valOsc1 * (1 - oscMix) + valOsc2 * oscMix + valNoise; // mix oscillators
			if (filterAmount > 0) {
				filteredSample = filter.applyFilter(filterType, filterCutoff, filterResonance, unfilteredSample);
				filteredSample = unfilteredSample * (1 - filterAmount) + filteredSample * filterAmount;
			} else {
				filteredSample = unfilteredSample;
			}

			// restore parameters to pre-envelope/modulation levels
			volume = volumeBase;
			pulseWidth = pulseWidthBase;
			filterAmount = filterAmountBase;
			filterCutoff = filterCutoffBase;
			
			// zero-out deltas at end of buffer
			if (j == sampleFrames - 1) {
				onDelta = 0;
				offDelta = 0;
			}
			
			// add filtered sample to output buffers
			outputL[j] += (float)filteredSample;
			outputR[j] += (float)filteredSample;
		}
	}
	
	private double incrementWrapPhase(double currentPhase, double phaseIncrement) {
		currentPhase += phaseIncrement;
		if (currentPhase >= 1.0) {
			currentPhase -= 2.0;
		} else if (currentPhase < -1.0) {
			currentPhase += 2.0;
		}
		return currentPhase;
	}
	
	private double interpolateLFO(double previousOffset, double currentOffset, int samples) {
		double intOffset;
		if (Math.abs(currentOffset - previousOffset) > 0.01) {
			intOffset = previousOffset + (currentOffset - previousOffset) / samples;
		} else {
			intOffset = currentOffset;
		}
		return intOffset;
	}
	
	// determine currently-selected scale and assign frequency
	private float calculateFrequency(int note) {
		float scale = instance.getScale();
		float frequency = 0.0F;
		if (scale < 0.167) {
			frequency = scales.JUST_FREQ_TAB[note];
		} else if (scale < 0.333) {
			frequency = scales.PYTHAGOREAN_FREQ_TAB[note];
		} else if (scale < 0.5) {
			frequency = scales.AULOS_FREQ_TAB[note];
		} else if (scale < 0.667) {
			frequency = scales.TWELVE_TET_FREQ_TAB[note];
		} else if (scale < 0.833) {
			frequency = scales.TWENTY_FOUR_TET_FREQ_TAB[note];
		} else {
			frequency = scales.SHRUTI_FREQ_TAB[note];
		}
		return frequency;
	}
	
	private float transposeByOcts(float octave, float frequency) {
		float fundFreq = scales.getFundFreq();
		float transposedByOcts = frequency;
		if (octave < 0.2 && frequency >= fundFreq * 4.0) {
			transposedByOcts = frequency * 0.25F;
		} else if (octave < 0.4 && frequency >= fundFreq * 2.0) {
			transposedByOcts = frequency * 0.5F;
		} else if (octave < 0.6) {
			transposedByOcts = frequency;
		} else if (octave < 0.8 && frequency < fundFreq * 128.0) {
			transposedByOcts = frequency * 2.0F;
		} else if (octave >= 0.8) {
			if (frequency < fundFreq * 64.0) {
				transposedByOcts = frequency * 4.0F;
			} else if (frequency < fundFreq * 128.0) {
				transposedByOcts = frequency * 2.0F;
			}
		}
		return transposedByOcts;
	}
	
	private float transposeBySub(float subharmFreq, float frequency) {
		float transposedBySub = frequency;
		if (subharmFreq < 0.167) {
			transposedBySub = frequency * (2.0F / 3.0F);
		} else if (subharmFreq < 0.333) {
			transposedBySub = frequency * (4.0F / 5.0F);
		} else if (subharmFreq < 0.5) {
			transposedBySub = frequency * (4.0F / 7.0F);
		} else if (subharmFreq < 0.667) {
			transposedBySub = frequency * (8.0F / 9.0F);
		} else if (subharmFreq < 0.833) {
			transposedBySub = frequency * (8.0F / 11.0F);
		} else {
			transposedBySub = frequency * (8.0F / 13.0F);
		}
		return transposedBySub;
	}
	
	private float transposeBySuper(float superharmFreq, float frequency) {
		float transposedBySuper = frequency;
		if (superharmFreq < 0.167) {
			transposedBySuper = frequency * (3.0F / 2.0F);
		} else if (superharmFreq < 0.333) {
			transposedBySuper = frequency * (5.0F / 4.0F);
		} else if (superharmFreq < 0.5) {
			transposedBySuper = frequency * (7.0F / 4.0F);
		} else if (superharmFreq < 0.667) {
			transposedBySuper = frequency * (9.0F / 8.0F);
		} else if (superharmFreq < 0.833) {
			transposedBySuper = frequency * (11.0F / 8.0F);
		} else {
			transposedBySuper = frequency * (13.0F / 8.0F);
		}
		return transposedBySuper;
	}

	public int getAmpEnvelope() {
		return ampEnvelope;
	}
	
	public int getNote() {
		return note;
	}
}