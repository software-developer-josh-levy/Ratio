/*
 * Ratio is a just intonation VST synthesizer built in Java. The Java-to-C++ wrapper
 * (jVSTwRapper) which encloses this synth was written by Daniel Martin
 * [daniel309@users.sourceforge.net] and many others. Ratio is adapted from and 
 * inspired by JayVSTxSynth (also written by Daniel Martin) and JSyn (by Phil Burk).
 *
 * Copyright (C) 2016 Josh Levy, https://github.com/software-developer-josh-levy/Ratio
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

package jvst.examples.ratio;

public class Oscillator {

private static final int NUM_TABLES = 8;
private static final int CYCLE_SIZE = (1 << 10);
private static final double LOWEST_PHASE_INC_INV = (1 << NUM_TABLES);

private double valOsc;
private int numTables;
private int tableSize;
private float[][] tables; 
private float[] sineTable;
private double phaseScalar;	

	public Oscillator() {
		this.makeTables();
	}
	
	public void makeTables() {
		int tableSize = CYCLE_SIZE + 1; /* 1025 elements--extra element is guard point to make tables continuous. */
		int numTables = NUM_TABLES; 
		tables = new float[numTables][tableSize]; /* 8 wavetables with 1025 elements each. */
		float[] sineTable = tables[0]; /* First table (index 0) is a sine--the root waveform. */
		phaseScalar = (float) (CYCLE_SIZE * 0.5); 

		/* Fill initial sine table with values for -PI to PI. */
		for (int j = 0; j < tableSize; j++) {
			sineTable[j] = (float) Math.sin(((((double) j) / (double) CYCLE_SIZE) * Math.PI * 2.0)
					- Math.PI);
		}

		/* Build each table from scratch and scale partials by raised cosine* to eliminate Gibbs effect. */
		for (int i = 1; i < numTables; i++) {
			int numPartials;
			double kGibbs;
			float[] table = tables[i];

			/* Add together partials for this table--"numPartials" is doubled for each successive table. */
			numPartials = 1 << i;
			kGibbs = Math.PI / (2 * numPartials);
			for (int k = 0; k < numPartials; k++) {
				double ampl, cGibbs;
				int sineIndex = 0;
				int partial = k + 1;
				cGibbs = Math.cos(k * kGibbs);
				/* Calculate amplitude for Nth partial. */
				ampl = cGibbs * cGibbs / partial;

				for (int j = 0; j < tableSize; j++) {
					table[j] += (float) ampl * sineTable[sineIndex];
					sineIndex += partial;
					/* Wrap index at end of table. */
					if (sineIndex >= CYCLE_SIZE) {
						sineIndex -= CYCLE_SIZE;
					}
				}
			}
		}

		/* Normalize after. */
		for (int i = 0; i < numTables; i++) {
			for (int j = 0; j < tables[i].length; j++) {
				tables[i][j] *= 1.0 / Math.PI;
			}
		}
	}
	
	public double calculateSample(float shape, float pulseWidth, double currentPhase, double phaseIncrement) {
		if (shape < 0.25) {
			valOsc = calculateSine(currentPhase);
		} else if (shape < 0.5) {
			valOsc = calculateTriangle(currentPhase);
		} else if (shape < 0.75) {
			valOsc = calculatePulse(pulseWidth, currentPhase, phaseIncrement);
		} else {
			valOsc = calculateSawtooth(currentPhase, phaseIncrement);					
		}
		return valOsc;
	}
	
	public double calculateSine(double currentPhase) {
		double calculatedSine = Math.sin(currentPhase * Math.PI);
		return calculatedSine;
	}
	
	public double calculateTriangle(double currentPhase) {
		double calculatedTriangle;
		if (currentPhase < -0.5) {
			calculatedTriangle = (-(currentPhase + 1.0)) * 2.0;
		} else if (currentPhase < 0.5) {
			calculatedTriangle = currentPhase * 2.0;
		} else {
			calculatedTriangle = (1.0 - currentPhase) * 2.0;
		}
		return calculatedTriangle;
	}
	
	public double calculatePulse(float pulseWidth, double currentPhase, double phaseIncrement) {
		pulseWidth = (pulseWidth > 0.875F) ? 0.875F : ((pulseWidth < 0) ? 0 : pulseWidth);
		double sawtooth1 = calculateSawtooth(currentPhase, phaseIncrement);
		
		// generate second sawtooth so we can add them together
		double currentOutOfPhase = currentPhase + 1.0 - pulseWidth; // 180 degrees out of phase
		if (currentOutOfPhase >= 1.0) {
			currentOutOfPhase -= 2.0;
		}
		double sawtooth2 = calculateSawtooth(currentOutOfPhase, phaseIncrement);
		double pulseScalar = 1.0 - phaseIncrement;
		double calculatedPulse = pulseScalar * (sawtooth1 - sawtooth2 - pulseWidth);
		return calculatedPulse;
	}
	
	public double calculateSawtooth(double currentPhase, double phaseIncrement) {
		float[] tableBase;
		double calculatedSawtooth;
		double hiSam; /* Use when "verticalFraction" is 1.0. */
		double loSam; /* Use when "verticalFraction" is 0.0. */
		double sam1, sam2;
		
		/*
		 * "fractionalIndex" is > 0 so we do not need to call floor().
		 * "sampleIndex" chops non-Integer portion of "fractionalIndex", leaving a sample index from 0 to 1024.
		 */
		double fractionalIndex = ((phaseScalar * currentPhase) + phaseScalar);
		int sampleIndex = (int) fractionalIndex;
		double horizontalFraction = fractionalIndex - sampleIndex;
		if (phaseIncrement < 1.0e-30) {
			phaseIncrement = 1.0e-30;
		}
		double fractionalLevel = -1.0 - (Math.log(phaseIncrement) / Math.log(2.0));
		
		/* "tableIndex" chops non-Integer portion of "fractionalLevel", leaving an octave index from 0-7. */
		int tableIndex = (int) fractionalLevel;
		if (tableIndex > (NUM_TABLES - 2)) { 
		
			/*
			 * Just use top table and mix with arithmetic sawtooth if below lowest frequency.
			 * Generate new fraction for interpolating between 0.0 and lowest table frequency.
			 */
			double fraction = phaseIncrement * LOWEST_PHASE_INC_INV; /* Range: 0-256. */
			
			tableBase = tables[(NUM_TABLES - 1)];

			/* Get adjacent samples. Assume guard point present. */
			sam1 = tableBase[sampleIndex];
			sam2 = tableBase[sampleIndex + 1];
			
			/* Interpolate between adjacent samples. */
			loSam = sam1 + (horizontalFraction * (sam2 - sam1));
			
			/*
			 * Use arithmetic version for low frequencies.
			 * "fraction" is 0.0 at 0 Hz.
			 */
			calculatedSawtooth = currentPhase + (fraction * (loSam - currentPhase));
			
		} else {			
		
			/* "verticalFraction" is the post-decimal-point portion of "fractionalLevel". */
			double verticalFraction = fractionalLevel - tableIndex;

			if (tableIndex < 0) { 
				if (tableIndex < -1) /* Above Nyquist! */
				{
					calculatedSawtooth = 0.0; /* No amplitude. */
					
				} else {
				
					/* At top of supported range, interpolate between 0.0 and first partial. */
					tableBase = tables[0]; /* Sine wave table. */

					/* Get adjacent samples. Assume guard point present. */
					sam1 = tableBase[sampleIndex];
					sam2 = tableBase[sampleIndex + 1];

					/* Interpolate between adjacent samples. */
					hiSam = sam1 + (horizontalFraction * (sam2 - sam1));
					
					/* "loSam" = 0.0. */
					calculatedSawtooth = verticalFraction * hiSam; /* "verticalFraction" is 0.0 at Nyquist. */
				}
				
			} else {
			
				/*
				 * Interpolate between adjacent levels to prevent harmonics from popping.
				 * Evaluate remaining octaves, "tableIndex" 0-5.
				 */
				tableBase = tables[tableIndex + 1];

				/* Get adjacent samples. Assume guard point present. */
				sam1 = tableBase[sampleIndex];
				sam2 = tableBase[sampleIndex + 1];

				/* Interpolate between adjacent samples. */
				hiSam = sam1 + (horizontalFraction * (sam2 - sam1));

				/* Get adjacent samples. Assume guard point present. */
				tableBase = tables[tableIndex];
				sam1 = tableBase[sampleIndex];
				sam2 = tableBase[sampleIndex + 1];

				/* Interpolate between adjacent samples. */
				loSam = sam1 + (horizontalFraction * (sam2 - sam1));

				calculatedSawtooth = loSam + (verticalFraction * (hiSam - loSam));
			}
		}
		return calculatedSawtooth;
	}
}