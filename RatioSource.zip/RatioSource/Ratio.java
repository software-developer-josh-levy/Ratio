/*
 * Ratio is a just intonation VST synthesizer built in Java. The Java-to-C++ wrapper
 * (jVSTwRapper) which encloses this synth was written by Daniel Martin
 * [daniel309@users.sourceforge.net] and many others. Ratio is adapted from and 
 * inspired by JayVSTxSynth (also written by Daniel Martin) and JSyn (by Phil Burk).
 *
 * Copyright (C) 2016 Josh Levy, https://github.com/software-developer-josh-levy/Ratio
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

package jvst.examples.ratio;

import jvst.wrapper.*;
import jvst.wrapper.valueobjects.*;
import java.text.DecimalFormat;

public class Ratio extends VSTPluginAdapter {
	private static final int NUM_PARAMETERS = 36;
	private static final int NUM_VOICES = 16;
	private static final int NUM_OUTPUTS = 2;
	private static final int FREE = 0;
	private static final float DEFAULT_SAMPLE_RATE = 44100.0F;
	private float sampleRate = DEFAULT_SAMPLE_RATE;
	
  	// parameters
  	private static final int
		VOLUME = 0,
		SCALE = 1,
		FUND_KEY = 2,
		KEY_MOD = 3,
		OSC1_SHAPE = 4,
		OSC2_SHAPE = 5,
		OSC1_OCTAVE = 6,
		OSC2_OCTAVE = 7,
		SUBHARM_LEVEL = 8,
		SUBHARM_FREQ = 9,
		SUPERHARM_LEVEL = 10,
		SUPERHARM_FREQ = 11,
		OSC_MIX = 12,
		OSC_DETUNE = 13,
		NOISE_LEVEL = 14,
		PULSE_WIDTH = 15,
		AMP_ATTACK = 16,
		AMP_DECAY = 17,
		AMP_SUSTAIN = 18,
		AMP_RELEASE = 19,
		FILTER_AMOUNT = 20,
		FILTER_TYPE = 21,
		FILTER_CUTOFF = 22,
		FILTER_RESONANCE = 23,
		FILTER_ATTACK = 24,
		FILTER_DECAY = 25,
		FILTER_SUSTAIN = 26,
		FILTER_RELEASE = 27,
		LFO1_AMOUNT = 28,
		LFO1_SHAPE = 29,
		LFO1_RATE = 30,
		LFO1_DESTINATION = 31,
		LFO2_AMOUNT = 32,
		LFO2_SHAPE = 33,
		LFO2_RATE = 34,
		LFO2_DESTINATION = 35;
	
	private float volume = 0.8125F;
	private float scale;
	private float fundKey;
	private float keyMod;
	private float osc1Shape;	
	private float osc2Shape;
	private float osc1Octave = 0.5F;
	private float osc2Octave = 0.5F;
	private float subharmLevel;
	private float subharmFreq;
	private float superharmLevel;
	private float superharmFreq;
	private float oscMix = 0.5F;
	private float oscDetune;	
	private float noiseLevel;
	private float pulseWidth = 0.428571F;
	private float ampAttack;
	private float ampDecay;
	private float ampSustain = 1.0F;
	private float ampRelease;
	private float filterAmount;
	private float filterType;
	private float filterCutoff = 1.0F;
	private float filterResonance;	
	private float filterAttack;
	private float filterDecay;
	private float filterSustain = 1.0F;
	private float filterRelease = 1.0F;
	private float LFO1Amount;
	private float LFO1Shape;
	private float LFO1Rate;
	private float LFO1Destination;
	private float LFO2Amount;
	private float LFO2Shape;
	private float LFO2Rate = 0.5F;
	private float LFO2Destination;
	
	private float ampAttackMS;
	private float ampDecayMS;
	private float ampReleaseMS;
	private float filterAttackMS;
	private float filterDecayMS;
	private float filterReleaseMS;
	private float filterCutoffHz;
	
	private static Ratio instance;
	private DecimalFormat df = new DecimalFormat("0.000");
	private Scales scales = new Scales();
	private Voice[] voices = new Voice[NUM_VOICES];
	private Oscillator osc = new Oscillator();
	private PinkNoise pinkNoise = new PinkNoise();
	
	public Ratio(long wrapper) {
		super(wrapper);
		log("Ratio() constructor started");
		this.setNumInputs(0); // no audio input, only MIDI input
		this.setNumOutputs(2); // stereo output
		this.canProcessReplacing(true);
		this.isSynth(true);
		this.setUniqueID('r'<<24 | 't'<<16 | 'i'<<8 | 'o');
		this.suspend();
		instance = this;
		for(int i = 0; i < NUM_VOICES; i++) {
			voices[i] = new Voice();
		}	
		log("Ratio() constructor invoked");
	}
	
	// deprecated as of VST 2.4
	// process() method is ACCUMULATING (out += h) the calculated floats to the output
	public void process(float[][] inputs, float[][] outputs, int sampleFrames) {
		VSTTimeInfo hostTempo = this.getTimeInfo(VSTTimeInfo.VST_TIME_TEMPO_VALID);
		double tempo = hostTempo.getTempo();
		float[] outputL = outputs[0];
		float[] outputR = outputs[1];

		for (int i = 0; i < NUM_VOICES; i++) {
			if (voices[i].getAmpEnvelope() != FREE) {			
				for (int j = 0; j < sampleFrames; j++) {
					voices[i].calculateSample(outputs, sampleRate, sampleFrames, tempo, j);
				}
			}
		}	
	}

	// processReplacing() method is REPLACING (out = h) the calculated floats to the output
	public void processReplacing(float[][] inputs, float[][] outputs, int sampleFrames) {
		VSTTimeInfo hostTempo = this.getTimeInfo(VSTTimeInfo.VST_TIME_TEMPO_VALID);
		double tempo = hostTempo.getTempo();
		float[] outputL = outputs[0];
		float[] outputR = outputs[1];

		for (int i = 0; i < NUM_VOICES; i++) {
			if (voices[i].getAmpEnvelope() != FREE) {			
				for (int j = 0; j < sampleFrames; j++) {
					voices[i].calculateSample(outputs, sampleRate, sampleFrames, tempo, j);
				}
			}
		}				
	}
    
	// parse MIDI message (to be used by process() and processReplacing())
	public int processEvents (VSTEvents ev) {
		for (int i = 0; i < ev.getNumEvents(); i++) {
			if (ev.getEvents()[i].getType() != VSTEvent.VST_EVENT_MIDI_TYPE) continue;
			VSTMidiEvent event = (VSTMidiEvent)ev.getEvents()[i];
			int delta = event.getDeltaFrames();
			byte[] midiData = event.getData();
			int status = midiData[0] & 0xf0; // ignoring channel
			if (status == 0x90 || status == 0x80) {
				// we only look at notes
				int note = midiData[1] & 0x7f;
				int velocity = midiData[2] & 0x7f;
				if (status == 0x80) {
					velocity = 0; // note off by velocity 0
				}
				if (velocity == 0) {
					noteOff(note, delta);
				} else {
					noteOn(note, velocity, delta);
				}
			}
			else if (status == 0xb0) {
				// all notes off
				int note = midiData[1] & 0x7f;
				if (midiData[1] == 0x7e || midiData[1] == 0x7b)	{
					allNotesOff(delta);
				}
			}
		}
		return 1; // want more
	}
	
	private void noteOn(int note, int velocity, int delta) {
		for (int i = 0; i < NUM_VOICES; i++) {
			int fundMIDI = scales.getFundMIDI();
			int numOctaves = scales.getNumOctaves12();
			// check if voice is free and MIDI note is in range
			if (voices[i].getAmpEnvelope() == FREE && note >= fundMIDI && note < fundMIDI + 12 * numOctaves) {	
				// send note to voice
				voices[i].noteOn(note, velocity, delta, volume, 
				ampAttackMS, ampDecayMS, ampSustain, ampReleaseMS, 
				filterAttackMS, filterDecayMS, filterSustain, filterReleaseMS);
				break;
			}
		}
	}

	private void noteOff(int note, int delta) {
		for (int i = 0; i < NUM_VOICES; i++) {
			if (voices[i].getNote() == note) {
				voices[i].noteOff(delta);
			}
		}
	}
	
	private void allNotesOff(int delta) {
		for (int i = 0; i < NUM_VOICES; i++) {
			voices[i].noteOff(delta);
		}
	}
	
	public void changeKey(float fundKey, float keyMod) {
		float baseFreq;
		float modFreq;
		int baseMIDI;
		int modMIDI;
		
		// establish base frequency and MIDI note
		if (fundKey < 0.0833) {
			baseFreq = 27.5F;
			baseMIDI = 21;
		} else if (fundKey < 0.167) {
			baseFreq = 14.567617F;
			baseMIDI = 10;
		} else if (fundKey < 0.25) {
			baseFreq = 15.433853F;
			baseMIDI = 11;
		} else if (fundKey < 0.333) {
			baseFreq = 16.351599F;
			baseMIDI = 12;
		} else if (fundKey < 0.417) {
			baseFreq = 17.323914F;
			baseMIDI = 13;
		} else if (fundKey < 0.5) {
			baseFreq = 18.354048F;
			baseMIDI = 14;
		} else if (fundKey < 0.583) {
			baseFreq = 19.445436F;
			baseMIDI = 15;
		} else if (fundKey < 0.667) {
			baseFreq = 20.601723F;
			baseMIDI = 16;
		} else if (fundKey < 0.75) {
			baseFreq = 21.826765F;
			baseMIDI = 17;
		} else if (fundKey < 0.833) {
			baseFreq = 23.124651F;
			baseMIDI = 18;
		} else if (fundKey < 0.917) {
			baseFreq = 24.499714F;
			baseMIDI = 19;
		} else {
			baseFreq = 25.956543F;
			baseMIDI = 20;
		}
		
		// modulate base frequency and MIDI note based on selected scale and modulation interval
		if (scale < 0.167) { // Just scale    
			if (keyMod == 0) { // no key modulation
				modFreq = baseFreq;
				modMIDI = baseMIDI;
			} else if (keyMod < 0.125) { // major 2nd
				modFreq = baseFreq * (9.0F / 8.0F);
				modMIDI = baseMIDI + 2;
			} else if (keyMod < 0.25) { // minor 3rd
				modFreq = baseFreq * (6.0F / 5.0F);
				modMIDI = baseMIDI + 3;
			} else if (keyMod < 0.375) { // major 3rd
				modFreq = baseFreq * (5.0F / 4.0F);
				modMIDI = baseMIDI + 4;
			} else if (keyMod < 0.5) { // perfect 4th
				modFreq = baseFreq * (4.0F / 3.0F);
				modMIDI = baseMIDI + 5;
			} else if (keyMod < 0.625) { // perfect 5th
				modFreq = baseFreq * (3.0F / 2.0F);
				modMIDI = baseMIDI + 7;
			} else if (keyMod < 0.75) { // minor 6th
				modFreq = baseFreq * (8.0F / 5.0F);
				modMIDI = baseMIDI + 8;
			} else if (keyMod < 0.875) { // major 6th
				modFreq = baseFreq * (5.0F / 3.0F);
				modMIDI = baseMIDI + 9;
			} else { // minor 7th
				modFreq = baseFreq * (7.0F / 4.0F);
				modMIDI = baseMIDI + 10;
			}
		} else if (scale < 0.333) { // Pythag scale
			if (keyMod == 0) { // no key modulation
				modFreq = baseFreq;
				modMIDI = baseMIDI;
			} else if (keyMod < 0.125) { // major 2nd
				modFreq = baseFreq * (9.0F / 8.0F);
				modMIDI = baseMIDI + 2;
			} else if (keyMod < 0.25) { // minor 3rd
				modFreq = baseFreq * (32.0F / 27.0F);
				modMIDI = baseMIDI + 3;
			} else if (keyMod < 0.375) { // major 3rd
				modFreq = baseFreq * (81.0F / 64.0F);
				modMIDI = baseMIDI + 4;
			} else if (keyMod < 0.5) { // perfect 4th
				modFreq = baseFreq * (4.0F / 3.0F);
				modMIDI = baseMIDI + 5;
			} else if (keyMod < 0.625) { // perfect 5th
				modFreq = baseFreq * (3.0F / 2.0F);
				modMIDI = baseMIDI + 7;
			} else if (keyMod < 0.75) { // minor 6th
				modFreq = baseFreq * (128.0F / 81.0F);
				modMIDI = baseMIDI + 8;
			} else if (keyMod < 0.875) { // major 6th
				modFreq = baseFreq * (27.0F / 16.0F);
				modMIDI = baseMIDI + 9;
			} else { // minor 7th
				modFreq = baseFreq * (16.0F / 9.0F);
				modMIDI = baseMIDI + 10;
			}							
		} else if (scale < 0.5) { // Aulos scale
			if (keyMod == 0) { // no key modulation
				modFreq = baseFreq;
				modMIDI = baseMIDI;
			} else if (keyMod < 0.125) { // major 2nd
				modFreq = baseFreq * (12.0F / 11.0F);
				modMIDI = baseMIDI + 2;
			} else if (keyMod < 0.25) { // minor 3rd
				modFreq = baseFreq * (8.0F / 7.0F);
				modMIDI = baseMIDI + 3;
			} else if (keyMod < 0.375) { // major 3rd
				modFreq = baseFreq * (6.0F / 5.0F);
				modMIDI = baseMIDI + 4;
			} else if (keyMod < 0.5) { // perfect 4th
				modFreq = baseFreq * (4.0F / 3.0F);
				modMIDI = baseMIDI + 6;
			} else if (keyMod < 0.625) { // perfect 5th
				modFreq = baseFreq * (3.0F / 2.0F);
				modMIDI = baseMIDI + 8;
			} else if (keyMod < 0.75) { // minor 6th
				modFreq = baseFreq * (8.0F / 5.0F);
				modMIDI = baseMIDI + 9;
			} else if (keyMod < 0.875) { // major 6th
				modFreq = baseFreq * (12.0F / 7.0F);
				modMIDI = baseMIDI + 10;
			} else { // minor 7th
				modFreq = baseFreq * (24.0F / 13.0F);
				modMIDI = baseMIDI + 11;
			}				
		} else if (scale < 0.667) { // 12-TET scale, no key modulation
			modFreq = 27.5F;
			modMIDI = 21;
		} else if (scale < 0.833) { // 24-TET scale, no key modulation
			modFreq = 27.5F;
			modMIDI = 21;
		} else { // Shruti scale
			if (keyMod == 0) { // no key modulation
				modFreq = baseFreq;
				modMIDI = baseMIDI;
			} else if (keyMod < 0.125) { // major 2nd
				modFreq = baseFreq * (9.0F / 8.0F);
				modMIDI = baseMIDI + 4;
			} else if (keyMod < 0.25) { // minor 3rd
				modFreq = baseFreq * (6.0F / 5.0F);
				modMIDI = baseMIDI + 6;
			} else if (keyMod < 0.375) { // major 3rd
				modFreq = baseFreq * (5.0F / 4.0F);
				modMIDI = baseMIDI + 8;
			} else if (keyMod < 0.5) { // perfect 4th
				modFreq = baseFreq * (4.0F / 3.0F);
				modMIDI = baseMIDI + 10;
			} else if (keyMod < 0.625) { // perfect 5th
				modFreq = baseFreq * (3.0F / 4.0F);
				modMIDI = baseMIDI - 10;
			} else if (keyMod < 0.75) { // minor 6th
				modFreq = baseFreq * (4.0F / 5.0F);
				modMIDI = baseMIDI - 8;
			} else if (keyMod < 0.875) { // major 6th
				modFreq = baseFreq * (5.0F / 6.0F);
				modMIDI = baseMIDI - 6;
			} else { // minor 7th
				modFreq = baseFreq * (8.0F / 9.0F);
				modMIDI = baseMIDI - 4;
			}				
		}		
		scales.setFundFreq(modFreq);
		scales.setFundMIDI(modMIDI);
		scales.makeScales();
	}
			
	public String getParameterName(int index) {
		String parameterName = "";
		switch (index) {
			case VOLUME: parameterName = "Volume"; break;
			case SCALE: parameterName = "Scale"; break;
			case FUND_KEY: parameterName = "FundKey"; break;
			case KEY_MOD: parameterName = "KeyMod"; break;
			case OSC1_SHAPE: parameterName = "Osc1Shp"; break;
			case OSC2_SHAPE: parameterName = "Osc2Shp"; break;
			case OSC1_OCTAVE: parameterName = "Osc1Oct"; break;
			case OSC2_OCTAVE: parameterName = "Osc2Oct"; break;
			case SUBHARM_LEVEL: parameterName = "SubLvl"; break;
			case SUBHARM_FREQ: parameterName = "SubFreq"; break;
			case SUPERHARM_LEVEL: parameterName = "SupLvl"; break;
			case SUPERHARM_FREQ: parameterName = "SupFreq"; break;
			case OSC_MIX: parameterName = "OscMix"; break;
			case OSC_DETUNE: parameterName = "Detune"; break;
			case NOISE_LEVEL: parameterName = "NoisLvl"; break;
			case PULSE_WIDTH: parameterName = "PulseWd"; break;
			case AMP_ATTACK: parameterName = "AmpAtt"; break;
			case AMP_DECAY: parameterName = "AmpDec"; break;
			case AMP_SUSTAIN: parameterName = "AmpSus"; break;
			case AMP_RELEASE: parameterName = "AmpRel"; break;
			case FILTER_AMOUNT: parameterName = "FiltAmt"; break;
			case FILTER_TYPE: parameterName = "FiltTyp"; break;
			case FILTER_CUTOFF: parameterName = "FiltCut"; break;
			case FILTER_RESONANCE: parameterName = "FiltRes"; break;			
			case FILTER_ATTACK: parameterName = "FiltAtt"; break;
			case FILTER_DECAY: parameterName = "FiltDec"; break;
			case FILTER_SUSTAIN: parameterName = "FiltSus"; break;
			case FILTER_RELEASE: parameterName = "FiltRel"; break;
			case LFO1_AMOUNT: parameterName = "LFO1Amt"; break;
			case LFO1_SHAPE: parameterName = "LFO1Shp"; break;
			case LFO1_RATE: parameterName = "LFO1Rte"; break;
			case LFO1_DESTINATION: parameterName = "LFO1Dst"; break;
			case LFO2_AMOUNT: parameterName = "LFO2Amt"; break;
			case LFO2_SHAPE: parameterName = "LFO2Shp"; break;
			case LFO2_RATE: parameterName = "LFO2Rte"; break;
			case LFO2_DESTINATION: parameterName = "LFO2Dst"; break;
		}
		return parameterName;
	}

	public String getParameterDisplay(int index) {
		String parameterDisplay = "";
		switch (index) {
			case VOLUME: {
				float volumeSquared = volume * volume;
				parameterDisplay = dbToString(volumeSquared);
				break;
			}
			case SCALE: {
				if (scale < 0.167) parameterDisplay = "Just";
				else if (scale < 0.333) parameterDisplay = "Pythag";
				else if (scale < 0.5) parameterDisplay = "Aulos";
				else if (scale < 0.667) parameterDisplay = "12-TET";
				else if (scale < 0.833) parameterDisplay = "24-TET";
				else parameterDisplay = "Shruti";
				break;
			}
			case FUND_KEY: {
				if (fundKey < 0.0833) parameterDisplay = "A";
				else if (fundKey < 0.167) parameterDisplay = "A#";
				else if (fundKey < 0.25) parameterDisplay = "B";
				else if (fundKey < 0.333) parameterDisplay = "C";
				else if (fundKey < 0.417) parameterDisplay = "C#";
				else if (fundKey < 0.5) parameterDisplay = "D";
				else if (fundKey < 0.583) parameterDisplay = "D#";
				else if (fundKey < 0.667) parameterDisplay = "E";
				else if (fundKey < 0.75) parameterDisplay = "F";
				else if (fundKey < 0.833) parameterDisplay = "F#";
				else if (fundKey < 0.917) parameterDisplay = "G";
				else parameterDisplay = "G#";
				break;
			}
			case KEY_MOD: {
				if (keyMod == 0) parameterDisplay = "None";
				else if (keyMod < 0.125) parameterDisplay = "M2";
				else if (keyMod < 0.25) parameterDisplay = "m3";
				else if (keyMod < 0.375) parameterDisplay = "M3";
				else if (keyMod < 0.5) parameterDisplay = "P4";
				else if (keyMod < 0.625) parameterDisplay = "P5";
				else if (keyMod < 0.75) parameterDisplay = "m6";
				else if (keyMod < 0.875) parameterDisplay = "M6";
				else parameterDisplay = "m7";	
				break;
			}
			case OSC1_SHAPE: {
				if (osc1Shape < 0.25) parameterDisplay = "Sine";
				else if (osc1Shape < 0.5) parameterDisplay = "Tri";
				else if (osc1Shape < 0.75) parameterDisplay = "Pulse";
				else parameterDisplay = "Saw";
				break;
			}
			case OSC2_SHAPE: {
				if (osc2Shape < 0.25) parameterDisplay = "Sine";
				else if (osc2Shape < 0.5) parameterDisplay = "Tri";
				else if (osc2Shape < 0.75) parameterDisplay = "Pulse";
				else parameterDisplay = "Saw";
				break;
			}
			case OSC1_OCTAVE: {
				if (osc1Octave < 0.2) parameterDisplay = "-2";
				else if (osc1Octave < 0.4) parameterDisplay = "-1";
				else if (osc1Octave < 0.6) parameterDisplay = "0";
				else if (osc1Octave < 0.8) parameterDisplay = "+1";
				else parameterDisplay = "+2";
				break;
			}
			case OSC2_OCTAVE: {
				if (osc2Octave < 0.2) parameterDisplay = "-2";
				else if (osc2Octave < 0.4) parameterDisplay = "-1";
				else if (osc2Octave < 0.6) parameterDisplay = "0";
				else if (osc2Octave < 0.8) parameterDisplay = "+1";
				else parameterDisplay = "+2";
				break;
			}
			case SUBHARM_LEVEL: {
				parameterDisplay = String.valueOf((int)(subharmLevel * 100));
				break;
			}
			case SUBHARM_FREQ: {
				if (subharmFreq < 0.167) parameterDisplay = "2/3";
				else if (subharmFreq < 0.333) parameterDisplay = "4/5";
				else if (subharmFreq < 0.5) parameterDisplay = "4/7";
				else if (subharmFreq < 0.667) parameterDisplay = "8/9";
				else if (subharmFreq < 0.833) parameterDisplay = "8/11";
				else parameterDisplay = "8/13";
				break;
			}
			case SUPERHARM_LEVEL: {
				parameterDisplay = String.valueOf((int)(superharmLevel * 100));
				break;
			}
			case SUPERHARM_FREQ: {
				if (superharmFreq < 0.167) parameterDisplay = "3/2";
				else if (superharmFreq < 0.333) parameterDisplay = "5/4";
				else if (superharmFreq < 0.5) parameterDisplay = "7/4";
				else if (superharmFreq < 0.667) parameterDisplay = "9/8";
				else if (superharmFreq < 0.833) parameterDisplay = "11/8";
				else parameterDisplay = "13/8";
				break;
			}						
			case OSC_MIX: {
				String osc1MixInt = String.valueOf((int)(100 - oscMix * 100));
				String osc2MixInt = String.valueOf((int)(oscMix * 100));
				parameterDisplay = osc1MixInt + "/" + osc2MixInt;
				break;
			}
			case OSC_DETUNE: {
				if (oscDetune < 0.167) parameterDisplay = "0";
				else if (oscDetune < 0.333) parameterDisplay = "1";
				else if (oscDetune < 0.5) parameterDisplay = "2";
				else if (oscDetune < 0.667) parameterDisplay = "3";
				else if (oscDetune < 0.833) parameterDisplay = "4";
				else if (oscDetune < 1) parameterDisplay = "5";
				else parameterDisplay = "6";
				break;
			}
			case NOISE_LEVEL: {
				parameterDisplay = String.valueOf((int)(noiseLevel * 100));
				break;
			}
			case PULSE_WIDTH: {
				parameterDisplay = String.valueOf(df.format(pulseWidth * 0.875));
				break;
			}
			case AMP_ATTACK: {
				ampAttackMS = (float)(ampAttack * ampAttack * ampAttack * 16000);
				if (ampAttackMS < 1000) {
					parameterDisplay = String.valueOf((int)ampAttackMS);
				} else {
					parameterDisplay = String.valueOf(df.format(ampAttackMS / 1000));
				}
				break;
			}
			case AMP_DECAY: {
				ampDecayMS = (float)(ampDecay * ampDecay * ampDecay * 16000);
				if (ampDecayMS < 1000) {
					parameterDisplay = String.valueOf((int)ampDecayMS);
				} else {
					parameterDisplay = String.valueOf(df.format(ampDecayMS / 1000));
				}
				break;
			}
			case AMP_SUSTAIN: {
				parameterDisplay = String.valueOf((int)(ampSustain * 100));
				break;
			}
			case AMP_RELEASE: {
				ampReleaseMS = (float)(ampRelease * ampRelease * ampRelease * 16000);
				if (ampReleaseMS < 1000) {
					parameterDisplay = String.valueOf((int)ampReleaseMS);
				} else {
					parameterDisplay = String.valueOf(df.format(ampReleaseMS / 1000));
				}
				break;
			}
			case FILTER_AMOUNT: {
				parameterDisplay = String.valueOf((int)(filterAmount * 100));
				break;
			}
			case FILTER_TYPE: {
				if (filterType < 0.5) parameterDisplay = "LoPass";
				else parameterDisplay = "HiPass";
				break;
			}
			case FILTER_CUTOFF: {
				filterCutoffHz = filterCutoff * 19980 + 20;
				parameterDisplay = String.valueOf((int)(filterCutoffHz));
				break;
			}
			case FILTER_RESONANCE: {
				parameterDisplay = String.valueOf(df.format(filterResonance));
				break;
			}		
			case FILTER_ATTACK: {
				filterAttackMS = (float)(filterAttack * filterAttack * filterAttack * 16000);
				if (filterAttackMS < 1000) {
					parameterDisplay = String.valueOf((int)filterAttackMS);
				} else {
					parameterDisplay = String.valueOf(df.format(filterAttackMS / 1000));
				}
				break;
			}
			case FILTER_DECAY: {
				filterDecayMS = (float)(filterDecay * filterDecay * filterDecay * 16000);
				if (filterDecayMS < 1000) {
					parameterDisplay = String.valueOf((int)filterDecayMS);
				} else {
					parameterDisplay = String.valueOf(df.format(filterDecayMS / 1000));
				}
				break;
			}
			case FILTER_SUSTAIN: {
				parameterDisplay = String.valueOf((int)(filterSustain * 100));
				break;
			}
			case FILTER_RELEASE: {
				filterReleaseMS = (float)(filterRelease * filterRelease * filterRelease * 16000);
				if (filterRelease < 1) {
					if (filterReleaseMS < 1000) {
						parameterDisplay = String.valueOf((int)filterReleaseMS);
					} else {
						parameterDisplay = String.valueOf(df.format(filterReleaseMS / 1000));
					}
				} else {
					parameterDisplay = "None";
				}
				break;
			}
			case LFO1_AMOUNT: {
				parameterDisplay = String.valueOf((int)(LFO1Amount * 100));
				break;
			}
			case LFO1_SHAPE: {
				if (LFO1Shape < 0.25) parameterDisplay = "Sine";
				else if (LFO1Shape < 0.5) parameterDisplay = "Tri";
				else if (LFO1Shape < 0.75) parameterDisplay = "Square";
				else parameterDisplay = "Saw";
				break;
			}
			case LFO1_RATE: {
				if (LFO1Rate > 0) {
					parameterDisplay = String.valueOf(df.format(LFO1Rate * 8));
				} else {
					parameterDisplay = String.valueOf(LFO1Rate * 8);
				}
				break;
			}
			case LFO1_DESTINATION: {
				if (LFO1Destination < 0.25) parameterDisplay = "Volume";
				else if (LFO1Destination < 0.5) parameterDisplay = "Freq";
				else if (LFO1Destination < 0.75) parameterDisplay = "FiltCut";
				else parameterDisplay = "PulseWd";
				break;	
			}
			case LFO2_AMOUNT: {
				parameterDisplay = String.valueOf((int)(LFO2Amount * 100));
				break;
			}
			case LFO2_SHAPE: {
				if (LFO2Shape < 0.25) parameterDisplay = "Sine";
				else if (LFO2Shape < 0.5) parameterDisplay = "Tri";
				else if (LFO2Shape < 0.75) parameterDisplay = "Square";
				else parameterDisplay = "Saw";
				break;
			}
			case LFO2_RATE: {
				if (LFO2Rate < 0.125) parameterDisplay = "1/16";
				else if (LFO2Rate < 0.25) parameterDisplay = "1/8";
				else if (LFO2Rate < 0.375) parameterDisplay = "1/4";
				else if (LFO2Rate < 0.5) parameterDisplay = "1/2";
				else if (LFO2Rate < 0.625) parameterDisplay = "1/1";
				else if (LFO2Rate < 0.75) parameterDisplay = "2/1";
				else if (LFO2Rate < 0.875) parameterDisplay = "4/1";
				else parameterDisplay = "8/1";		
				break;
			}
			case LFO2_DESTINATION: {
				if (LFO2Destination < 0.25) parameterDisplay = "Volume";
				else if (LFO2Destination < 0.5) parameterDisplay = "Freq";
				else if (LFO2Destination < 0.75) parameterDisplay = "FiltCut";
				else parameterDisplay = "PulseWd";
				break;	
			} 
		}
		return parameterDisplay;
	}

	public String getParameterLabel(int index) {
		String parameterLabel = "";
		switch (index) {
			case VOLUME: parameterLabel = "dB"; break;
			case SCALE: parameterLabel = ""; break;
			case FUND_KEY: parameterLabel = ""; break;
			case KEY_MOD: parameterLabel = ""; break;
			case OSC1_SHAPE: parameterLabel = ""; break;
			case OSC2_SHAPE: parameterLabel = ""; break;
			case OSC1_OCTAVE: parameterLabel = ""; break;
			case OSC2_OCTAVE: parameterLabel = ""; break;
			case SUBHARM_LEVEL: parameterLabel = ""; break;
			case SUBHARM_FREQ: parameterLabel = ""; break;
			case SUPERHARM_LEVEL: parameterLabel = ""; break;
			case SUPERHARM_FREQ: parameterLabel = ""; break;
			case OSC_MIX: parameterLabel = ""; break;
			case OSC_DETUNE: parameterLabel = " cents"; break;
			case NOISE_LEVEL: parameterLabel = ""; break;
			case PULSE_WIDTH: parameterLabel = ""; break;
			case AMP_ATTACK: {
				if (ampAttackMS < 1000) parameterLabel = "ms";
				else parameterLabel = "s";
				break;
			}
			case AMP_DECAY: {
				if (ampDecayMS < 1000) parameterLabel = "ms";
				else parameterLabel = "s";
				break;
			}
			case AMP_SUSTAIN: parameterLabel = "%"; break;
			case AMP_RELEASE: {
				if (ampReleaseMS < 1000) parameterLabel = "ms";
				else parameterLabel = "s";
				break;
			}
			case FILTER_AMOUNT: parameterLabel = ""; break;
			case FILTER_TYPE: parameterLabel = ""; break;
			case FILTER_CUTOFF: parameterLabel = "Hz"; break;
			case FILTER_RESONANCE: parameterLabel = ""; break;			
			case FILTER_ATTACK: {
				if (filterAttackMS < 1000) parameterLabel = "ms";
				else parameterLabel = "s";
				break;
			}
			case FILTER_DECAY: {
				if (filterDecayMS < 1000) parameterLabel = "ms";
				else parameterLabel = "s";
				break;
			}
			case FILTER_SUSTAIN: parameterLabel = "%"; break;
			case FILTER_RELEASE: {
				if (filterReleaseMS < 1000) parameterLabel = "ms";
				else if (filterReleaseMS < 16000)  parameterLabel = "s";
				else parameterLabel = "";
				break;
			}
			case LFO1_AMOUNT: parameterLabel = ""; break;
			case LFO1_SHAPE: parameterLabel = ""; break;
			case LFO1_RATE: parameterLabel = "Hz"; break;
			case LFO1_DESTINATION: parameterLabel = ""; break;
			case LFO2_AMOUNT: parameterLabel = ""; break;
			case LFO2_SHAPE: parameterLabel = ""; break;
			case LFO2_RATE: parameterLabel = ""; break;
			case LFO2_DESTINATION: parameterLabel = ""; break;
		}
		return parameterLabel;
	}
	
	public float getParameter(int index) {
		float parameterValue = 0;  
		switch (index) {
			case VOLUME: parameterValue = volume; break;
			case SCALE: parameterValue = scale; break;
			case FUND_KEY: parameterValue = fundKey; break;
			case KEY_MOD: parameterValue = keyMod; break;
			case OSC1_SHAPE: parameterValue = osc1Shape; break;
			case OSC2_SHAPE: parameterValue = osc2Shape; break;
			case OSC1_OCTAVE: parameterValue = osc1Octave; break;
			case OSC2_OCTAVE: parameterValue = osc2Octave; break;
			case SUBHARM_LEVEL: parameterValue = subharmLevel; break;
			case SUBHARM_FREQ: parameterValue = subharmFreq; break;
			case SUPERHARM_LEVEL: parameterValue = superharmLevel; break;
			case SUPERHARM_FREQ: parameterValue = superharmFreq; break;
			case OSC_MIX: parameterValue = oscMix; break;
			case OSC_DETUNE: parameterValue = oscDetune; break;
			case NOISE_LEVEL: parameterValue = noiseLevel; break;
			case PULSE_WIDTH: parameterValue = pulseWidth; break;
			case AMP_ATTACK: parameterValue = ampAttack; break;
			case AMP_DECAY: parameterValue = ampDecay; break;
			case AMP_SUSTAIN: parameterValue = ampSustain; break;
			case AMP_RELEASE: parameterValue = ampRelease; break;
			case FILTER_AMOUNT: parameterValue = filterAmount; break;
			case FILTER_TYPE: parameterValue = filterType; break;
			case FILTER_CUTOFF: parameterValue = filterCutoff; break;
			case FILTER_RESONANCE: parameterValue = filterResonance; break;			
			case FILTER_ATTACK: parameterValue = filterAttack; break;
			case FILTER_DECAY: parameterValue = filterDecay; break;
			case FILTER_SUSTAIN: parameterValue = filterSustain; break;
			case FILTER_RELEASE: parameterValue = filterRelease; break;
			case LFO1_AMOUNT: parameterValue = LFO1Amount; break;
			case LFO1_SHAPE: parameterValue = LFO1Shape; break;
			case LFO1_RATE: parameterValue = LFO1Rate; break;
			case LFO1_DESTINATION: parameterValue = LFO1Destination; break;
			case LFO2_AMOUNT: parameterValue = LFO2Amount; break;
			case LFO2_SHAPE: parameterValue = LFO2Shape; break;
			case LFO2_RATE: parameterValue = LFO2Rate; break;
			case LFO2_DESTINATION: parameterValue = LFO2Destination; break;
		}
		return parameterValue;
	}

	public void setParameter(int index, float value) {
		switch (index) {
			case VOLUME: volume = value; break;
			case SCALE: scale = value; break;
			case FUND_KEY: { // set fundamental key
				fundKey = value;
				changeKey(fundKey, keyMod);
				break;
			}
			case KEY_MOD: { // modulate key
				keyMod = value;
				changeKey(fundKey, keyMod);
				break;
			}
			case OSC1_SHAPE: osc1Shape = value; break;
			case OSC2_SHAPE: osc2Shape = value; break;
			case OSC1_OCTAVE: osc1Octave = value; break;
			case OSC2_OCTAVE: osc2Octave = value; break;
			case SUBHARM_LEVEL: subharmLevel = value; break;
			case SUBHARM_FREQ: subharmFreq = value; break;
			case SUPERHARM_LEVEL: superharmLevel = value; break;
			case SUPERHARM_FREQ: superharmFreq = value; break;
			case OSC_MIX: oscMix = value; break;
			case OSC_DETUNE: oscDetune = value; break;
			case NOISE_LEVEL: noiseLevel = value; break;
			case PULSE_WIDTH: pulseWidth = value; break; 
			case AMP_ATTACK: ampAttack = value; break;
			case AMP_DECAY: ampDecay = value; break;
			case AMP_SUSTAIN: ampSustain = value; break;
			case AMP_RELEASE: ampRelease = value; break;
			case FILTER_AMOUNT: filterAmount = value; break;
			case FILTER_TYPE: filterType = value; break;
			case FILTER_CUTOFF: filterCutoff = value; break;
			case FILTER_RESONANCE: filterResonance = value; break;			
			case FILTER_ATTACK: filterAttack = value; break;
			case FILTER_DECAY: filterDecay = value; break;
			case FILTER_SUSTAIN: filterSustain = value; break;
			case FILTER_RELEASE: filterRelease = value; break;
			case LFO1_AMOUNT: LFO1Amount = value; break;
			case LFO1_SHAPE: LFO1Shape = value; break; 
			case LFO1_RATE: LFO1Rate = value; break;
			case LFO1_DESTINATION: LFO1Destination = value; break;
			case LFO2_AMOUNT: LFO2Amount = value; break;
			case LFO2_SHAPE: LFO2Shape = value; break; 
			case LFO2_RATE: LFO2Rate = value; break;
			case LFO2_DESTINATION: LFO2Destination = value; break;
		}
	}

	public VSTPinProperties getOutputProperties (int index) {
		VSTPinProperties outputProperties = null;
		if (index < NUM_OUTPUTS) {
			outputProperties = new VSTPinProperties();
			outputProperties.setLabel("Ratio " + (index + 1) + "d");
			outputProperties.setFlags(VSTPinProperties.VST_PIN_IS_ACTIVE);
			if (index < 2) outputProperties.setFlags(outputProperties.getFlags() | VSTPinProperties.VST_PIN_IS_STEREO);
		}
		return outputProperties;
	}

	public String getEffectName() { return "Ratio"; }
	public String getVendorString() { return "XHZ Software"; }
	public String getProductString() { return "Ratio"; }
	public boolean setBypass(boolean value) { return false; }
	public int getNumPrograms() { return 0; }
	public int getNumParams() { return NUM_PARAMETERS; }
	public int getProgram() { return 0; }
	public int getPlugCategory() { return VSTPluginAdapter.PLUG_CATEG_SYNTH; }

	public int canDo(String feature) {
	int ret = Ratio.CANDO_NO;
		if (Ratio.CANDO_PLUG_RECEIVE_VST_EVENTS.equals(feature)) ret = Ratio.CANDO_YES;
		if (Ratio.CANDO_PLUG_RECEIVE_VST_MIDI_EVENT.equals(feature)) ret = Ratio.CANDO_YES;
		if (Ratio.CANDO_PLUG_RECEIVE_VST_TIME_INFO.equals(feature)) ret = Ratio.CANDO_YES;
		if (Ratio.CANDO_PLUG_MIDI_PROGRAM_NAMES.equals(feature)) ret = Ratio.CANDO_YES;
	return ret;
	}
	
	public static Ratio getInstance() {
		return instance;
	}

	public void setSampleRate(float sampleRate) {
		this.sampleRate = sampleRate;
	}
	
	public Scales getScales() {
		return scales;
	}
	
	public float getVolume() {
		return volume;
	}
	
	public float getScale() {
		return scale;
	}
	
	public Oscillator getOsc() {
		return osc;
	}
		
	public PinkNoise getPinkNoise() {
		return pinkNoise;
	}
	
	public float getOsc1Shape() {
		return osc1Shape;
	}
	
	public float getOsc2Shape() {
		return osc2Shape;
	}
	
	public float getOsc1Octave() {
		return osc1Octave;
	}
	
	public float getOsc2Octave() {
		return osc2Octave;
	}

	public float getSubharmLevel() {
		return subharmLevel;
	}
	
	public float getSubharmFreq() {
		return subharmFreq;
	}
	
	public float getSuperharmLevel() {
		return superharmLevel;
	}
	
	public float getSuperharmFreq() {
		return superharmFreq;
	}
	
	public float getOscMix() {
		return oscMix;
	}
	
	public float getOscDetune() {
		return oscDetune;
	}

	public float getNoiseLevel() {
		return noiseLevel;
	}
	
	public float getPulseWidth() {
		return pulseWidth * 0.875F;
	}
	
	public float getFilterAmount() {
		return filterAmount;
	}
	
	public float getFilterType() {
		return filterType;
	}
	
	public float getFilterCutoff() {
		return filterCutoff;
	}
	
	public float getFilterResonance() {
		return filterResonance;
	}
	
	public float getLFO1Amount() {
		return LFO1Amount;
	}
	
	public float getLFO2Amount() {
		return LFO2Amount;
	}
	
	public float getLFO1Shape() {
		return LFO1Shape;
	}
	
	public float getLFO2Shape() {
		return LFO2Shape;
	}
	
	public float getLFO1Rate() {
		return LFO1Rate;
	}
	
	public float getLFO2Rate() {
		return LFO2Rate;
	}
	
	public float getLFO1Destination() {
		return LFO1Destination;
	}
	
	public float getLFO2Destination() {
		return LFO2Destination;
	}

	public void setProgram(int index) {
	}
	
	public String getProgramName() {
		return "";
	}
	
	public String getProgramNameIndexed(int category, int index) {
		return "";
	}

	public void setProgramName(String name) {
	}
	
	public boolean string2Parameter(int index, String value) {
		return false;
	}
}



