/*
 * Ratio is a just intonation VST synthesizer built in Java. The Java-to-C++ wrapper
 * (jVSTwRapper) which encloses this synth was written by Daniel Martin
 * [daniel309@users.sourceforge.net] and many others. Ratio is adapted from and 
 * inspired by JayVSTxSynth (also written by Daniel Martin) and JSyn (by Phil Burk).
 *
 * Copyright (C) 2016 Josh Levy, https://github.com/software-developer-josh-levy/Ratio
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
 
 // Timo Tossavainen version of Stilson/Smith Moog filter emulation--from musicdsp.org.

package jvst.examples.ratio;

public class Filter {
	private double in1, in2, in3, in4;
	private double out1, out2, out3, out4;

	public double applyFilter(float filterType, float filterCutoff, float filterResonance, double unfilteredSample) {	
		if (filterCutoff < 0.001F) { // minimum cutoff
			filterCutoff = 0.001F;
		}
		if (filterCutoff > 1) { // maximum cutoff
			filterCutoff = 1;
		}
		filterResonance *= 4;
		double input = unfilteredSample;
		double f = filterCutoff * 1.16;
		double fb = filterResonance * (1.0 - 0.15 * f * f); 
		input -= (out4 - input) * fb;
		input *= 0.35013 * (f*f)*(f*f);
		out1 = input + 0.3 * in1 + (1 - f) * out1; // Pole 1
		in1  = input;
		out2 = out1 + 0.3 * in2 + (1 - f) * out2;  // Pole 2
		in2  = out1;
		out3 = out2 + 0.3 * in3 + (1 - f) * out3;  // Pole 3
		in3  = out2;
		out4 = out3 + 0.3 * in4 + (1 - f) * out4;  // Pole 4
		out4 = out4 - out4 * out4 * out4 * 0.166667f; // clipping
		in4  = out3;
		if (filterType < 0.5) { // low-pass	
			return out4;
		} else { // high-pass;
			return (unfilteredSample - out4) * (1 - filterCutoff * filterCutoff * filterCutoff);
		}				
	}
	
	public void zeroOut() {
		in1 = in2 = in3 = in4 = 0;
		out1 = out2 = out3 = out4 = 0;
	}
}