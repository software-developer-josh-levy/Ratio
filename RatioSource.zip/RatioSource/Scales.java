/*
 * Ratio is a just intonation VST synthesizer built in Java. The Java-to-C++ wrapper
 * (jVSTwRapper) which encloses this synth was written by Daniel Martin
 * [daniel309@users.sourceforge.net] and many others. Ratio is adapted from and 
 * inspired by JayVSTxSynth (also written by Daniel Martin) and JSyn (by Phil Burk).
 *
 * Copyright (C) 2016 Josh Levy, https://github.com/software-developer-josh-levy/Ratio
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

package jvst.examples.ratio;

public class Scales {

	protected static final int NUM_OCTAVES_12 = 8; // range: A0 to G#8
	protected static final int NUM_OCTAVES_24 = NUM_OCTAVES_12 / 2; 
	protected static float TWELVE_TET_FREQ_TAB[] = new float[128];
	protected static float JUST_FREQ_TAB[] = new float[128];
	protected static float PYTHAGOREAN_FREQ_TAB[] = new float[128];
	protected static float AULOS_FREQ_TAB[] = new float[128]; 
	protected static float TWENTY_FOUR_TET_FREQ_TAB[] = new float[128]; 
	protected static float SHRUTI_FREQ_TAB[] = new float[128];
	private float fundFreq = 27.5F; // note A0
	private int fundMIDI = 21; // MIDI note A0

	public Scales() {
		// make 12-tone equal temperament (12-TET) scale
		double k12 = 1.0594630943593; // 12th root of 2
		double a12 = 27.5F;
		for (int i = 0; i < (NUM_OCTAVES_12 * 12); i++) {
			TWELVE_TET_FREQ_TAB[21 + i] = (float)a12;
			a12 *= k12;
		}  
		
		// make 24-tone equal temperament (24-TET) scale
		double k24 = 1.02930223664349; // 24th root of 2
		double a24 = 110.0F;
		for (int i = 0; i < (NUM_OCTAVES_12 * 12); i++) {
			TWENTY_FOUR_TET_FREQ_TAB[21 + i] = (float)a24;
			a24 *= k24;
		}
		this.makeScales();
	}
	
	public void makeScales() {
		// make Just scale--12 notes per octave
		for (int i = 0; i < NUM_OCTAVES_12; i++) { // fundamental tone
			JUST_FREQ_TAB[fundMIDI + (12 * i)] = fundFreq * (float)(Math.pow(2, i));
		}
		for (int i = 0; i < NUM_OCTAVES_12; i++) { // minor 2nd--fundamental * 16/15 
			JUST_FREQ_TAB[fundMIDI + 1 + (12 * i)] = fundFreq * (float)((16.0 / 15.0) * Math.pow(2, i));
		}
		for (int i = 0; i < NUM_OCTAVES_12; i++) { // major 2nd--fundamental * 9/8 
			JUST_FREQ_TAB[fundMIDI + 2 + (12 * i)] = fundFreq * (float)((9.0 / 8.0) * Math.pow(2, i));
		}
		for (int i = 0; i < NUM_OCTAVES_12; i++) { // minor 3rd--fundamental * 6/5 
			JUST_FREQ_TAB[fundMIDI + 3 + (12 * i)] = fundFreq * (float)((6.0 / 5.0) * Math.pow(2, i));
		}
		for (int i = 0; i < NUM_OCTAVES_12; i++) { // major 3rd--fundamental * 5/4 
			JUST_FREQ_TAB[fundMIDI + 4 + (12 * i)] = fundFreq * (float)((5.0 / 4.0) * Math.pow(2, i));
		}
		for (int i = 0; i < NUM_OCTAVES_12; i++) { // perfect 4th--fundamental * 4/3 
			JUST_FREQ_TAB[fundMIDI + 5 + (12 * i)] = fundFreq * (float)((4.0 / 3.0) * Math.pow(2, i));
		}
		for (int i = 0; i < NUM_OCTAVES_12; i++) { // tritone--fundamental * 7/5 
			JUST_FREQ_TAB[fundMIDI + 6 + (12 * i)] = fundFreq * (float)((7.0 / 5.0) * Math.pow(2, i));
		}
		for (int i = 0; i < NUM_OCTAVES_12; i++) { // perfect 5th--fundamental * 3/2 
			JUST_FREQ_TAB[fundMIDI + 7 + (12 * i)] = fundFreq * (float)((3.0 / 2.0) * Math.pow(2, i));
		}
		for (int i = 0; i < NUM_OCTAVES_12; i++) { // minor 6th--fundamental * 8/5 
			JUST_FREQ_TAB[fundMIDI + 8 + (12 * i)] = fundFreq * (float)((8.0 / 5.0) * Math.pow(2, i));
		}
		for (int i = 0; i < NUM_OCTAVES_12; i++) { // major 6th--fundamental * 5/3 
			JUST_FREQ_TAB[fundMIDI + 9 + (12 * i)] = fundFreq * (float)((5.0 / 3.0) * Math.pow(2, i));
		}
		for (int i = 0; i < NUM_OCTAVES_12; i++) { // minor 7th--fundamental * 7/4 
			JUST_FREQ_TAB[fundMIDI + 10 + (12 * i)] = fundFreq * (float)((7.0 / 4.0) * Math.pow(2, i));
		}
		for (int i = 0; i < NUM_OCTAVES_12; i++) { // major 7th--fundamental * 15/8 
			JUST_FREQ_TAB[fundMIDI + 11 + (12 * i)] = fundFreq * (float)((15.0 / 8.0) * Math.pow(2, i));
		}
		
		// make Pythagorean scale--12 notes per octave
		for (int i = 0; i < NUM_OCTAVES_12; i++) { // fundamental tone
			PYTHAGOREAN_FREQ_TAB[fundMIDI + (12 * i)] = fundFreq * (float)(Math.pow(2, i));
		}
		for (int i = 0; i < NUM_OCTAVES_12; i++) { // minor 2nd--fundamental * 256/243 
			PYTHAGOREAN_FREQ_TAB[fundMIDI + 1 + (12 * i)] = fundFreq * (float)((256.0 / 243.0) * Math.pow(2, i));
		}
		for (int i = 0; i < NUM_OCTAVES_12; i++) { // major 2nd--fundamental * 9/8 
			PYTHAGOREAN_FREQ_TAB[fundMIDI + 2 + (12 * i)] = fundFreq * (float)((9.0 / 8.0) * Math.pow(2, i));
		}
		for (int i = 0; i < NUM_OCTAVES_12; i++) { // minor 3rd--fundamental * 32/27 
			PYTHAGOREAN_FREQ_TAB[fundMIDI + 3 + (12 * i)] = fundFreq * (float)((32.0 / 27.0) * Math.pow(2, i));
		}
		for (int i = 0; i < NUM_OCTAVES_12; i++) { // major 3rd--fundamental * 81/64 
			PYTHAGOREAN_FREQ_TAB[fundMIDI + 4 + (12 * i)] = fundFreq * (float)((81.0 / 64.0) * Math.pow(2, i));
		}
		for (int i = 0; i < NUM_OCTAVES_12; i++) { // perfect 4th--fundamental * 4/3 
			PYTHAGOREAN_FREQ_TAB[fundMIDI + 5 + (12 * i)] = fundFreq * (float)((4.0 / 3.0) * Math.pow(2, i));
		}
		for (int i = 0; i < NUM_OCTAVES_12; i++) { // tritone--fundamental * 729/512 
			PYTHAGOREAN_FREQ_TAB[fundMIDI + 6 + (12 * i)] = fundFreq * (float)((729.0 / 512.0) * Math.pow(2, i));
		}
		for (int i = 0; i < NUM_OCTAVES_12; i++) { // perfect 5th--fundamental * 3/2 
			PYTHAGOREAN_FREQ_TAB[fundMIDI + 7 + (12 * i)] = fundFreq * (float)((3.0 / 2.0) * Math.pow(2, i));
		}
		for (int i = 0; i < NUM_OCTAVES_12; i++) { // minor 6th--fundamental * 128/81 
			PYTHAGOREAN_FREQ_TAB[fundMIDI + 8 + (12 * i)] = fundFreq * (float)((128.0 / 81.0) * Math.pow(2, i));
		}
		for (int i = 0; i < NUM_OCTAVES_12; i++) { // major 6th--fundamental * 27/16 
			PYTHAGOREAN_FREQ_TAB[fundMIDI + 9 + (12 * i)] = fundFreq * (float)((27.0 / 16.0) * Math.pow(2, i));
		}
		for (int i = 0; i < NUM_OCTAVES_12; i++) { // minor 7th--fundamental * 16/9 
			PYTHAGOREAN_FREQ_TAB[fundMIDI + 10 + (12 * i)] = fundFreq * (float)((16.0 / 9.0) * Math.pow(2, i));
		}
		for (int i = 0; i < NUM_OCTAVES_12; i++) { // major 7th--fundamental * 243/128 
			PYTHAGOREAN_FREQ_TAB[fundMIDI + 11 + (12 * i)] = fundFreq * (float)((243.0 / 128.0) * Math.pow(2, i));
		}
		
		// make Aulos scale--12 notes per octave
		for (int i = 0; i < NUM_OCTAVES_12; i++) { // scale tone #1--fundamental tone
			AULOS_FREQ_TAB[fundMIDI + (12 * i)] = fundFreq * (float)(Math.pow(2, i));
		}
		for (int i = 0; i < NUM_OCTAVES_12; i++) { // scale tone #2--fundamental * 24/23 
			AULOS_FREQ_TAB[fundMIDI + 1 + (12 * i)] = fundFreq * (float)((24.0 / 23.0) * Math.pow(2, i));
		}
		for (int i = 0; i < NUM_OCTAVES_12; i++) { // scale tone #3--fundamental * 24/22 (12/11)
			AULOS_FREQ_TAB[fundMIDI + 2 + (12 * i)] = fundFreq * (float)((12.0 / 11.0) * Math.pow(2, i));
		}
		for (int i = 0; i < NUM_OCTAVES_12; i++) { // scale tone #4--undamental * 24/21 (8/7)
			AULOS_FREQ_TAB[fundMIDI + 3 + (12 * i)] = fundFreq * (float)((8.0 / 7.0) * Math.pow(2, i));
		}
		for (int i = 0; i < NUM_OCTAVES_12; i++) { // scale tone #5--fundamental * 24/20 (6/5)
			AULOS_FREQ_TAB[fundMIDI + 4 + (12 * i)] = fundFreq * (float)((6.0 / 5.0) * Math.pow(2, i));
		}
		for (int i = 0; i < NUM_OCTAVES_12; i++) { // scale tone #6--fundamental * 24/19 
			AULOS_FREQ_TAB[fundMIDI + 5 + (12 * i)] = fundFreq * (float)((24.0 / 19.0) * Math.pow(2, i));
		}
		for (int i = 0; i < NUM_OCTAVES_12; i++) { // scale tone #7--fundamental * 24/18 (4/3)
			AULOS_FREQ_TAB[fundMIDI + 6 + (12 * i)] = fundFreq * (float)((4.0 / 3.0) * Math.pow(2, i));
		}
		for (int i = 0; i < NUM_OCTAVES_12; i++) { // scale tone #8--fundamental * 24/17 
			AULOS_FREQ_TAB[fundMIDI + 7 + (12 * i)] = fundFreq * (float)((24.0 / 17.0) * Math.pow(2, i));
		}
		for (int i = 0; i < NUM_OCTAVES_12; i++) { // scale tone #9--fundamental * 24/16 (3/2)
			AULOS_FREQ_TAB[fundMIDI + 8 + (12 * i)] = fundFreq * (float)((3.0 / 2.0) * Math.pow(2, i));
		}
		for (int i = 0; i < NUM_OCTAVES_12; i++) { // scale tone #10--fundamental * 24/15 (8/5)
			AULOS_FREQ_TAB[fundMIDI + 9 + (12 * i)] = fundFreq * (float)((8.0 / 5.0) * Math.pow(2, i));
		}
		for (int i = 0; i < NUM_OCTAVES_12; i++) { // scale tone #11--fundamental * 24/14 (10/7)
			AULOS_FREQ_TAB[fundMIDI + 10 + (12 * i)] = fundFreq * (float)((12.0 / 7.0) * Math.pow(2, i));
		}
		for (int i = 0; i < NUM_OCTAVES_12; i++) { // scale tone #12--fundamental * 24/13 
			AULOS_FREQ_TAB[fundMIDI + 11 + (12 * i)] = fundFreq * (float)((24.0 / 13.0) * Math.pow(2, i));
		}
		
		// make Shruti scale--24 notes per octave
		for (int i = 0; i < NUM_OCTAVES_24; i++) { // scale tone #1--fundamental tone
			SHRUTI_FREQ_TAB[fundMIDI + (24 * i)] = fundFreq * 4.0F * (float)(Math.pow(2, i));
		}
		for (int i = 0; i < NUM_OCTAVES_24; i++) { // scale tone #2--fundamental * 256/243 
			SHRUTI_FREQ_TAB[fundMIDI + 1 + (24 * i)] = fundFreq * 4.0F * (float)((256.0 / 243.0) * Math.pow(2, i));
		}
		for (int i = 0; i < NUM_OCTAVES_24; i++) { // scale tone #3--fundamental * 16/15 
			SHRUTI_FREQ_TAB[fundMIDI + 2 + (24 * i)] = fundFreq * 4.0F * (float)((16.0 / 15.0) * Math.pow(2, i));
		}
		for (int i = 0; i < NUM_OCTAVES_24; i++) { // scale tone #4--fundamental * 10/9 
			SHRUTI_FREQ_TAB[fundMIDI + 3 + (24 * i)] = fundFreq * 4.0F * (float)((10.0 / 9.0) * Math.pow(2, i));
		}
		for (int i = 0; i < NUM_OCTAVES_24; i++) { // scale tone #5--fundamental * 9/8 
			SHRUTI_FREQ_TAB[fundMIDI + 4 + (24 * i)] = fundFreq * 4.0F * (float)((9.0 / 8.0) * Math.pow(2, i));
		}
		for (int i = 0; i < NUM_OCTAVES_24; i++) { // scale tone #6--fundamental * 32/27 
			SHRUTI_FREQ_TAB[fundMIDI + 5 + (24 * i)] = fundFreq * 4.0F * (float)((32.0 / 27.0) * Math.pow(2, i));
		}
		for (int i = 0; i < NUM_OCTAVES_24; i++) { // scale tone #7--fundamental * 6/5 
			SHRUTI_FREQ_TAB[fundMIDI + 6 + (24 * i)] = fundFreq * 4.0F * (float)((6.0 / 5.0) * Math.pow(2, i));
		}
		for (int i = 0; i < NUM_OCTAVES_24; i++) { // scale tone #8--fundamental * 11/9 
			SHRUTI_FREQ_TAB[fundMIDI + 7 + (24 * i)] = fundFreq * 4.0F * (float)((11.0 / 9.0) * Math.pow(2, i));
		}
		for (int i = 0; i < NUM_OCTAVES_24; i++) { // scale tone #9--fundamental * 5/4 
			SHRUTI_FREQ_TAB[fundMIDI + 8 + (24 * i)] = fundFreq * 4.0F * (float)((5.0 / 4.0) * Math.pow(2, i));
		}
		for (int i = 0; i < NUM_OCTAVES_24; i++) { // scale tone #10--fundamental * 81/64 
			SHRUTI_FREQ_TAB[fundMIDI + 9 + (24 * i)] = fundFreq * 4.0F * (float)((81.0 / 64.0) * Math.pow(2, i));
		}
		for (int i = 0; i < NUM_OCTAVES_24; i++) { // scale tone #11--fundamental * 4/3 
			SHRUTI_FREQ_TAB[fundMIDI + 10 + (24 * i)] = fundFreq * 4.0F * (float)((4.0 / 3.0) * Math.pow(2, i));
		}
		for (int i = 0; i < NUM_OCTAVES_24; i++) { // scale tone #12--fundamental * 27/20 
			SHRUTI_FREQ_TAB[fundMIDI + 11 + (24 * i)] = fundFreq * 4.0F * (float)((27.0 / 20.0) * Math.pow(2, i));
		}
		for (int i = 0; i < NUM_OCTAVES_24; i++) { // scale tone #13--fundamental * 45/32 
			SHRUTI_FREQ_TAB[fundMIDI + 12 + (24 * i)] = fundFreq * 4.0F * (float)((45.0 / 32.0) * Math.pow(2, i));
		}
		for (int i = 0; i < NUM_OCTAVES_24; i++) { // scale tone #14--fundamental * 729/512 
			SHRUTI_FREQ_TAB[fundMIDI + 13 + (24 * i)] = fundFreq * 4.0F * (float)((729.0 / 512.0) * Math.pow(2, i));
		}
		for (int i = 0; i < NUM_OCTAVES_24; i++) { // scale tone #15--fundamental * 3/2 
			SHRUTI_FREQ_TAB[fundMIDI + 14 + (24 * i)] = fundFreq * 4.0F * (float)((3.0 / 2.0) * Math.pow(2, i));
		}
		for (int i = 0; i < NUM_OCTAVES_24; i++) { // scale tone #16--fundamental * 128/81 
			SHRUTI_FREQ_TAB[fundMIDI + 15 + (24 * i)] = fundFreq * 4.0F * (float)((128.0 / 81.0) * Math.pow(2, i));
		}
		for (int i = 0; i < NUM_OCTAVES_24; i++) { // scale tone #17--fundamental * 8/5 
			SHRUTI_FREQ_TAB[fundMIDI + 16 + (24 * i)] = fundFreq * 4.0F * (float)((8.0 / 5.0) * Math.pow(2, i));
		}
		for (int i = 0; i < NUM_OCTAVES_24; i++) { // scale tone #18--fundamental * 13/8 
			SHRUTI_FREQ_TAB[fundMIDI + 17 + (24 * i)] = fundFreq * 4.0F * (float)((13.0 / 8.0) * Math.pow(2, i));
		}
		for (int i = 0; i < NUM_OCTAVES_24; i++) { // scale tone #19--fundamental * 5/3 
			SHRUTI_FREQ_TAB[fundMIDI + 18 + (24 * i)] = fundFreq * 4.0F * (float)((5.0 / 3.0) * Math.pow(2, i));
		}
		for (int i = 0; i < NUM_OCTAVES_24; i++) { // scale tone #20--fundamental * 27/16
			SHRUTI_FREQ_TAB[fundMIDI + 19 + (24 * i)] = fundFreq * 4.0F * (float)((27.0 / 16.0) * Math.pow(2, i));
		}
		for (int i = 0; i < NUM_OCTAVES_24; i++) { // scale tone #21--fundamental * 16/9
			SHRUTI_FREQ_TAB[fundMIDI + 20 + (24 * i)] = fundFreq * 4.0F * (float)((16.0 / 9.0) * Math.pow(2, i));
		}
		for (int i = 0; i < NUM_OCTAVES_24; i++) { // scale tone #22--fundamental * 9/5
			SHRUTI_FREQ_TAB[fundMIDI + 21 + (24 * i)] = fundFreq * 4.0F * (float)((9.0 / 5.0) * Math.pow(2, i));
		}
		for (int i = 0; i < NUM_OCTAVES_24; i++) { // scale tone #23--fundamental * 15/8
			SHRUTI_FREQ_TAB[fundMIDI + 22 + (24 * i)] = fundFreq * 4.0F * (float)((15.0 / 8.0) * Math.pow(2, i));
		}
		for (int i = 0; i < NUM_OCTAVES_24; i++) { // scale tone #24--fundamental * 243/128
			SHRUTI_FREQ_TAB[fundMIDI + 23 + (24 * i)] = fundFreq * 4.0F * (float)((243.0 / 128.0) * Math.pow(2, i));
		}
	}
	
	public float getFundFreq() {
		return fundFreq;
	}
	
	public void setFundFreq(float frequency) {
		fundFreq = frequency;
	}
		
	public int getFundMIDI() {
		return fundMIDI;
	}
	
	public void setFundMIDI(int note) {
		fundMIDI = note;
	}
	
	public int getNumOctaves12() {
		return NUM_OCTAVES_12;
	}
}